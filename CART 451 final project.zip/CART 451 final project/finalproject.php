<!doctypeHTML>
<html>
	<head>
	<title> Wishlist </title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="style2.css">
	<script src="script.js"></script>
  <head>

  <body>
		<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@1,800&display=swap" rel="stylesheet">
  <h1> Wishlist </h1>

  <p><span style="white-space:pre-wrap;">Websites: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; Devices: </span> </p>


	<rectangle>
	<img
	src="amazon.jpg"
	alt="amazon logo"
	position= absolute
	width="150"
	height= "70px"
	left= "500px"
	top= "300px"
	id="picture"
	>
  </rectangle>

	<rectangle2>
	<img
	src="Best.Buy.jpg"
	alt="best buy logo"
	position= absolute
	width="150"
	height= "100px"
	left= "500px"
	top= "300px"
	id="picture"
	>
  </rectangle2>

	<rectangle3>
	<img
	src="walmart.png"
	alt="walmart logo"
	position= absolute
	width="150"
	height= "100px"
	left= "500px"
	top= "300px"
	id="picture"
	>
  </rectangle3>

	<rectangle4>
	<img
	src="target.png"
	alt="target logo"
	position= absolute
	width="150"
	height= "85px"
	left= "500px"
	top= "300px"
	id="picture"
	>
  </rectangle4>

	<rectangle5>
	<img
	src="apple.png"
	alt="apple logo"
	position= absolute
	width="150"
	height= "175px"
	left= "500px"
	top= "300px"
	id="picture"
	>
  </rectangle5>

	<rectangle6>
	<img
	src="Samsung.jpg"
	alt="samsung logo"
	position= absolute
	width="150"
	height= "95px"
	left= "500px"
	top= "300px"
	id="picture"
	>
  </rectangle6>

	<rectangle7>
	</rectangle7>

	<rectangle8>
	</rectangle8>

	<rectangle9>
	</rectangle9>

	<rectangle10>
	</rectangle10>

	<rectangle11>
	</rectangle11>

	<rectangle12>
	</rectangle12>

	<rectangle13>
	</rectangle13>

	<rectangle14>
	</rectangle14>

	<rectangle15>
	</rectangle15>

	<rectangle16>
	</rectangle16>

	<rectangle17>
	</rectangle17>

	<rectangle18>
	</rectangle18>

	<rectangle19>
	</rectangle19>

	<rectangle20>
	</rectangle20>

	<rectangle21>
	</rectangle21>

	<rectangle22>
	</rectangle22>

	<rectangle23>
	</rectangle23>

	<rectangle24>
	</rectangle24>

	<rectangle25>
	</rectangle25>

	<rectangle26>
	</rectangle26>

	<rectangle27>
	</rectangle27>

	<rectangle28>
	</rectangle28>

	<rectangle29>
	</rectangle29>

	<rectangle30>
	</rectangle30>

	<!-- <rectangle31> -->
	<img
	src="santa.png"
	alt="Santa and his reindeer"
	position= relative
	width= 150px
	height= 100px
	left= 5px
	top= 1713px
	id="santa"
	>
<!-- </rectangle31> -->

<!-- first row -->
	<p1>
			<a href="https://www.amazon.com/s?k=laptops&ref=nb_sb_noss_1" >Laptops</a>
	</p1>

	<p2>
			<a href="https://www.amazon.com/s?k=phones&rh=n%3A2811119011&ref=nb_sb_noss" >Phones</a>
	</p2>

	<p3>
			<a href="https://www.amazon.com/s?k=headphones&rh=n%3A2811119011&ref=nb_sb_noss" >Headphones</a>
	</p3>

	<p4>
			<a href="https://www.amazon.com/s?k=electronics+accessories+%26+supplies&i=electronics-accessories&crid=3UJO14QHO4SEM&sprefix=electroni%2Celectronics-accessories%2C253&ref=nb_sb_ss_ts-a-p_1_9" >Accessories</a>
	</p4>

<!-- second row -->
<p5>
		<a href="https://www.bestbuy.com/site/searchpage.jsp?st=laptops&_dyncharset=UTF-8&_dynSessConf=&id=pcat17071&type=page&sc=Global&cp=1&nrp=&sp=&qp=&list=n&af=true&iht=y&usc=All+Categories&ks=960&keys=keys" >Laptops</a>
</p5>

<p6>
		<a href="https://www.bestbuy.com/site/electronics/mobile-cell-phones/abcat0800000.c?id=abcat0800000&#58;" >Phones</a>
</p6>

<p7>
		<a href="https://www.bestbuy.com/site/searchpage.jsp?st=headphones&_dyncharset=UTF-8&_dynSessConf=&id=pcat17071&type=page&sc=Global&cp=1&nrp=&sp=&qp=&list=n&af=true&iht=y&usc=All+Categories&ks=960&keys=keys" >Headphones</a>
</p7>

<p8>
		<a href="https://www.bestbuy.com/site/mobile-cell-phones/mobile-phone-accessories/abcat0811002.c?id=abcat0811002" >Accessories</a>
</p8>

<!-- third row -->
<p9>
		<a href="https://www.walmart.com/search/?query=laptops" >Laptops</a>
</p9>

<p10>
		<a href="https://www.walmart.com/search/?query=smartphones&cat_id=3944" >Phones</a>
</p10>

<p11>
		<a href="https://www.walmart.com/search/?query=headphones" >Headphones</a>
</p11>

<p12>
		<a href="https://www.walmart.com/search/?query=electronic%20accessories%20" >Accessories</a>
</p12>

<!-- fourth row -->
<p13>
		<a href="https://www.target.com/s?searchTerm=laptops" >Laptops</a>
</p13>

<p14>
		<a href="https://www.target.com/s?searchTerm=smartphones" >Phones</a>
</p14>

<p15>
		<a href="https://www.target.com/s?searchTerm=headphones" >Headphones</a>
</p15>

<p16>
		<a href="https://www.target.com/s?searchTerm=electronic+accessories" >Accessories</a>
</p16>

<!-- fifth row -->
<p17>
		<a href="https://www.apple.com/mac/" >Laptops</a>
</p17>

<p18>
		<a href="https://www.apple.com/iphone/" >Phones</a>
</p18>

<p19>
		<a href="https://www.apple.com/airpods/" >Headphones</a>
</p19>

<p20>
		<a href="https://www.apple.com/shop/accessories/all" >Accessories</a>
</p20>

<!-- sixth row -->
<p21>
		<a href="https://www.samsung.com/us/computing/laptops/all-laptops/" >Laptops</a>
</p21>

<p22>
		<a href="https://www.samsung.com/us/smartphones/" >Phones</a>
</p22>

<p23>
		<a href="https://www.samsung.com/us/mobile-audio/" >Headphones</a>
</p23>

<p24>
		<a href="https://www.samsung.com/us/mobile/mobile-accessories/all-mobile-accessories/" >Accessories</a>
</p24>

<p25>
There's a special gift for you if you hold down what's next to q.
</p25>

<?php
require("index.php");
 ?>

  </body>
	</html>
