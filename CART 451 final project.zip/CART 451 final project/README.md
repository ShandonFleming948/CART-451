This is my CART 451 final project.

The project is essentially a website that the user can interact with and use to
navigate through a variety of the top online shopping websites in order the see
the top deals on each. In theory, the user would then be able to make the decision
of purchasing something they desire from the website that they decide offers
them the best deal. 
