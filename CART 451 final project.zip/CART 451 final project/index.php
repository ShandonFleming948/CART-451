<form action="index.php" method="get">
Submit your notes or suggestions here:<input type="text" name="user">
<input type="submit" value="submit">
</form>
<?php
if(isset($_GET["user"])){
$user=$_GET["user"];

$f=fopen("info.txt","a");
fwrite($f,"username:".$user."\n");
fclose($f);
}
?>
