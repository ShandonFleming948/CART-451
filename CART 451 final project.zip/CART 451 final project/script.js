let myVariable;
let position = 0;
const sound = new Audio("bark.wav");
const sound2 = new Audio("SleighBellsRinging.wav");

let picturehorizontal = 0;
let picturevertical = 0;
let santahorizontal = 0;

if (typeof(window.Storage)!= "undefined")
{
  picturehorizontal = parseInt(window.localStorage.getItem("picturehorizontal"));
  picturevertical = parseInt(window.localStorage.getItem("picturevertical"));
}

let madeit = false;
let dragging = false;

let verticalvelocity = 0;
let horizontalvelocity = 0;

setInterval(movePicture, 20);
setInterval(updatePosition, 10);
document.addEventListener("keydown", keyboard);
document.addEventListener("keyup", onKeyUp);
document.addEventListener("mousemove", onMouseMove);


function onLoad()
{
  document.getElementById("thebutton").style.position = "relative";
  document.ondragstart = canceldrag;

  document.getElementById("picture").style.left = picturehorizontal + "px";
  document.getElementById("picture").style.top = picturevertical + "px";

}

function canceldrag()
{
  return false;
}

function updatePosition()
{
  picturehorizontal = picturehorizontal + horizontalvelocity;
  picturevertical = picturevertical + verticalvelocity;

  document.getElementById("picture").style.left = picturehorizontal + "px";
  document.getElementById("picture").style.top = picturevertical + "px";

  window.localStorage.setItem("picturehorizontal",picturehorizontal);
  window.localStorage.setItem("picturevertical",picturevertical);
}

function movePicture()
{
  if (position >= 400)
  {
    clearInterval(movePicture);
  }
  else
  {
  position = position + 1;
  document.getElementById("thebutton").style.left = position + "px";
  }
}

function myFunction()
{
  document.getElementById("demo").innerHTML = "New Title;"
  document.getElementById("demo").innerHTML = myVariable;

  document.getElementById("movingpicture").src = "technologybackground.gif";

  document.getElementById("demo").style.fontSize = "5em";

  document.getElementById("disappear").style.display = "none";

  sound.play();
}

function keyboard(parameter)
{
  // if (parameter.keyCode == 65)
  // {
  //   horizontalvelocity = - 5;
  // }
  // else if (parameter.keyCode == 68)
  // {
  //   horizontalvelocity = 5;
  // }

  if (parameter.keyCode == 87) {
    santahorizontal = santahorizontal + 4;
    document.getElementById("santa").style.left = santahorizontal + "px";
    sound2.play();

    // verticalvelocity = - 5;
  }
  // else if (parameter.keyCode == 83)
  // {
  //   verticalvelocity = 5;
  // }
  //
  // document.getElementById("picture").style.left = picturehorizontal + "px";
  // document.getElementById("picture").style.top = picturevertical + "px";

  if (santahorizontal >= 930 )
  {
    window.alert("Congratulations you just won a $100,000 gift card to any website of your choice!");
    // madeit = true;
    // sound2.play();
  }
}

function onKeyUp(parameter)
{
  verticalvelocity = 0;
  horizontalvelocity = 0;
}

function drag()
{
  dragging = true;
}

function drop()
{
  dragging = false;
}

function onMouseMove(event)
{
  if (dragging)
  {
    picturevertical = event.pageY - 50;
    picturehorizontal = event.pageX - 90;

    document.getElementById("picture").style.left = picturehorizontal + "px";
    document.getElementById("picture").style.top = picturevertical + "px";
  }
}
